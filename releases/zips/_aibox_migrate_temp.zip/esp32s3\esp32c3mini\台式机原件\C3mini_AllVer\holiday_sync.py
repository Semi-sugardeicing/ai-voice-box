#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
节假日表同步工具（在电脑上跑，不在板子上跑）

作用：从 api.jiejiariapi.com 拉取中国法定节假日安排，
      生成一段 C++ 代码，直接替换掉 c3mini_display.ino 里
      "中国法定节假日表" 那一整块（到 "/* 存储 */" 之前）。

用法：
    python holiday_sync.py                # 默认拉 2026、2027
    python holiday_sync.py 2026 2027 2028 # 拉指定年份

接口每年发布一次（国务院发通知后才会有数据）：
    2027 年没发布时返回 "Year not found"，脚本会跳过并写注释，
    不会把好的数据弄坏。

依赖：只用标准库，不需要 pip 装东西。
"""

import json
import sys
import urllib.request

API = "https://api.jiejiariapi.com/v1/holidays/%d"
DEFAULT_YEARS = [2026, 2027]


def fetch(year):
    """返回 dict，或者 None（该年还没发布）"""
    req = urllib.request.Request(API % year, headers={
        "User-Agent": "Mozilla/5.0 (holiday_sync for ESP32)",
    })
    with urllib.request.urlopen(req, timeout=20) as r:
        raw = r.read().decode("utf-8").strip()
    if not raw or "not found" in raw.lower() or not raw.startswith("{"):
        return None
    return json.loads(raw)


def build(years):
    rows = []
    ok_years = []
    for y in years:
        try:
            data = fetch(y)
        except Exception as e:
            print("# %d 年拉取失败：%s" % (y, e), file=sys.stderr)
            continue
        if not data:
            print("# %d 年官方还没发布，跳过" % y, file=sys.stderr)
            continue
        ok_years.append(y)
        rows.append("  /* ---- %d 年 ---- */" % y)
        for date in sorted(data):
            info = data[date]
            md = int(date[5:7]) * 100 + int(date[8:10])
            off = "true " if info["isOffDay"] else "false"
            rows.append("  { %d, %4d, %s },   /* %s %s */"
                        % (y, md, off, date, info["name"]))

    if not ok_years:
        raise SystemExit("一个年份都没拿到，检查网络或年份是否已发布")

    block = []
    block.append("/* ================= 中国法定节假日表 ================= */")
    block.append("/* 来源：api.jiejiariapi.com，最后一次同步（holiday_sync.py）")
    block.append("     offDay = true  放假，整天按低谷算")
    block.append("     offDay = false 调休上班，按正常工作日算高低峰")
    block.append("   表里带年份，可以同时放好几年；某年没查到就跳过判断 */")
    block.append("struct HolidayItem { int year; int md; bool offDay; };")
    block.append("const HolidayItem HOLIDAYS[] = {")
    block.extend(rows)
    block.append("};")
    block.append("const int HOL_N = sizeof(HOLIDAYS) / sizeof(HOLIDAYS[0]);")
    block.append("")
    block.append("/* 板子里有数据的年份范围（用来判断是不是该换表了） */")
    block.append("const int HOL_YEAR_MIN = %d;" % min(ok_years))
    block.append("const int HOL_YEAR_MAX = %d;" % max(ok_years))
    return "\n".join(block)


def main():
    years = [int(a) for a in sys.argv[1:]] or DEFAULT_YEARS
    out = build(years)
    print(out)
    print()
    print("把上面从「中国法定节假日表」到 HOL_YEAR_MAX 这一整段，")
    print("替换掉 c3mini_display.ino 里同名的那一段即可。")


if __name__ == "__main__":
    main()
