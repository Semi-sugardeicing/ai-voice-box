/* 屏幕诊断固件 v2 —— 给 ESP32-C3 SuperMini 找 OLED
   1) 扫描多组引脚, 找到 SSD1306 (0x3C/0x3D)
   2) 一旦找到, 当场初始化并把文字画上去 —— 屏幕会亮, 直接看出成不成
   她的接法: SDA=GPIO3, SCL=GPIO5 */

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define LED_PIN 8
#define SCR_W 128
#define SCR_H 64

struct Pins { uint8_t sda; uint8_t scl; const char* note; };

Pins CANDIDATES[] = {
  { 3,  5,  "她现在的接法 SDA=3 SCL=5" },
  { 5,  3,  "反接试试 SDA=5 SCL=3" },
  { 4,  5,  "C3 SuperMini 常见默认" },
  { 5,  6,  "有些板如此" },
  { 8,  9,  "S3 默认" },
  { 0,  1,  "C3 的 0/1" },
  { 2,  3,  "C3 的 2/3" },
  { 6,  7,  "C3 的 6/7" },
  { 20, 21, "C3 的 20/21" },
};
const int NP = sizeof(CANDIDATES) / sizeof(CANDIDATES[0]);

Adafruit_SSD1306 *disp = nullptr;

void blink(int times) {
  for (int i = 0; i < times; i++) {
    digitalWrite(LED_PIN, LOW);  delay(100);
    digitalWrite(LED_PIN, HIGH); delay(100);
  }
}

void drawText(uint8_t sda, uint8_t scl, uint8_t addr) {
  disp->clearDisplay();
  disp->setTextColor(SSD1306_WHITE);
  disp->setTextSize(2);
  disp->setCursor(4, 4);  disp->print("SCREEN OK");
  disp->setTextSize(1);
  disp->setCursor(4, 30); disp->printf("SDA=%u  SCL=%u", sda, scl);
  disp->setCursor(4, 42); disp->printf("addr 0x%02X", addr);
  disp->setCursor(4, 54); disp->print("AI BOX diag");
  disp->display();
}

bool lightUp(uint8_t sda, uint8_t scl, uint8_t addr) {
  Serial.printf(">>> 尝试点亮: SDA=%u SCL=%u addr=0x%02X\n", sda, scl, addr);
  Wire.end();
  Wire.begin(sda, scl);
  Wire.setClock(100000);
  delay(50);

  if (disp) { delete disp; disp = nullptr; }
  disp = new Adafruit_SSD1306(SCR_W, SCR_H, &Wire, -1);
  if (!disp->begin(SSD1306_SWITCHCAPVCC, addr)) {
    Serial.println(">>> begin() 失败: 地址能通但初始化不过");
    return false;
  }
  Serial.println(">>> begin() 成功, 正在画图");
  drawText(sda, scl, addr);
  delay(1500);
  /* 满屏白闪一下, 排除"初始化了但对比度太低看不见" */
  disp->fillScreen(SSD1306_WHITE);
  disp->display();
  delay(800);
  drawText(sda, scl, addr);
  return true;
}

void scanAll(bool tryLight) {
  int lit = 0;
  for (int k = 0; k < NP; k++) {
    uint8_t sda = CANDIDATES[k].sda, scl = CANDIDATES[k].scl;
    Serial.printf("--- SDA=%u SCL=%u  (%s)\n", sda, scl, CANDIDATES[k].note);
    Wire.end();
    Wire.begin(sda, scl);
    Wire.setClock(100000);
    delay(30);

    int found = 0;
    for (uint8_t addr = 0x08; addr <= 0x77; addr++) {
      Wire.beginTransmission(addr);
      if (Wire.endTransmission() == 0) {
        bool isOled = (addr == 0x3C || addr == 0x3D);
        Serial.printf("    >>> 设备 0x%02X%s\n", addr, isOled ? "  <== SSD1306 屏幕" : "");
        found++;
        if (tryLight && isOled && lit == 0) {
          if (lightUp(sda, scl, addr)) lit = 1;
        }
      }
    }
    if (!found) Serial.println("    (无设备)");
    Serial.println();
  }
  if (lit) Serial.println("### 屏幕已点亮 ###");
  else {
    Serial.println("### 没有点亮任何屏幕 ###");
    Serial.println("检查: 1) VCC 必须 3.3V  2) GND 共地  3) SDA/SCL 是否插反  4) 屏幕坏没坏");
  }
}

void setup() {
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, HIGH);
  Serial.begin(115200);
  delay(1200);

  Serial.println();
  Serial.println("########## OLED 诊断 v2 ##########");
  Serial.printf("chip=%s cores=%d flash=%uKB heap=%u\n",
                ESP.getChipModel(), ESP.getChipCores(),
                (unsigned)(ESP.getFlashChipSize() / 1024), (unsigned)ESP.getFreeHeap());
  Serial.println("你给的接法: SDA=3, SCL=5 —— 先试这个");
  Serial.println();
  scanAll(true);
  Serial.println();
  Serial.println("(之后每 10 秒重扫一次, 可以边接线边看; 板载灯每次闪一下)");
}

void loop() {
  delay(10000);
  blink(1);
  scanAll(false);
}
