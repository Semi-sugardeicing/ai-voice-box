/*
  屏幕诊断测试 (C3)
  烧进去后屏幕循环显示三种图案:
    1. 全白 2 秒
    2. 全黑 2 秒
    3. 白框 + 大号 C3 OK + 一行小字 4 秒 (期间整屏反色闪一次)
  看屏幕属于哪种情况:
    A. 全程纯黑, 啥都没有      -> 供电/对比度/屏损坏
    B. 能看到全白但看不到字   -> 字库/坐标问题(不太可能)
    C. 有图案但位置错乱/花屏  -> 可能是 SH1106 或 128x32 屏
    D. 很暗很淡               -> 对比度问题
  串口 115200 也会打印走到了哪一步
*/
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

Adafruit_SSD1306 display(128, 64, &Wire, -1);
int g_sda = -1, g_scl = -1;

void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println("=== SCREEN TEST ===");

  bool ok = false;
  const int TRY_PAIRS[2][2] = { {8, 9}, {4, 5} };
  for (int i = 0; i < 2 && !ok; i++) {
    int sda = TRY_PAIRS[i][0], scl = TRY_PAIRS[i][1];
    Wire.end();
    delay(100);
    Wire.begin(sda, scl);
    Wire.setClock(100000);
    ok = display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
    Serial.printf("try SDA=%d SCL=%d -> %s\n", sda, scl, ok ? "OK" : "no");
    if (ok) { g_sda = sda; g_scl = scl; }
  }
  Serial.println(ok ? "screen OK" : "screen NOT FOUND");
  if (!ok) while (true) delay(1000);
}

void loop() {
  /* 1. 全白 */
  Serial.println("STEP 1: all white");
  display.fillRect(0, 0, 128, 64, SSD1306_WHITE);
  display.display();
  delay(2000);

  /* 2. 全黑 */
  Serial.println("STEP 2: all black");
  display.fillRect(0, 0, 128, 64, SSD1306_BLACK);
  display.display();
  delay(2000);

  /* 3. 边框 + 大字 */
  Serial.println("STEP 3: frame + text");
  display.clearDisplay();
  display.drawRect(0, 0, 128, 64, SSD1306_WHITE);
  display.setTextSize(3);
  display.setTextColor(SSD1306_WHITE);
  display.setCursor(18, 16);
  display.print("C3 OK");
  display.setTextSize(1);
  display.setCursor(6, 48);
  display.print("SDA=" );
  display.print(g_sda);
  display.print(" SCL=");
  display.print(g_scl);
  display.display();
  delay(2000);
  display.invertDisplay(true);
  Serial.println("STEP 3b: inverted");
  delay(2000);
  display.invertDisplay(false);
}
