/* 屏幕点灯测试 —— 只为了一件事: 让屏幕亮起来
   不联网、不管别的功能。
   做法: 挨个试引脚组合, 谁能找到 SSD1306 就把字画上去并停在那里 */

#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define LED_PIN 8

struct P { uint8_t sda, scl; };
P LIST[] = {
  { 3,  5  },   /* 你现在的接法, 第一个试 */
  { 5,  3  },   /* 万一接反 */
  { 4,  5  },   /* C3 SuperMini 常见 */
  { 5,  6  },
  { 8,  9  },   /* S3 默认, C3 上碰运气 */
  { 0,  1  },
  { 2,  3  },
  { 6,  7  },
  { 20, 21 },
};
const int N = sizeof(LIST) / sizeof(LIST[0]);

Adafruit_SSD1306 *d = NULL;

void pixelTest(int sda, int scl, int addr) {
  d->clearDisplay();
  d->setTextColor(SSD1306_WHITE);
  d->setTextSize(2);
  d->setCursor(10, 6);   d->print("HELLO");
  d->setTextSize(1);
  d->setCursor(0, 30);   d->printf("SDA=%d SCL=%d", sda, scl);
  d->setCursor(0, 42);   d->printf("addr 0x%02X OK", addr);
  d->setCursor(0, 54);   d->print("screen works!");
  d->display();
}

void setup() {
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, HIGH);
  Serial.begin(115200);
  delay(1500);                      /* 给 USB 串口一点时间被电脑/手机识别 */
  Serial.println();
  Serial.println("========== SCREEN TEST ==========");
  Serial.printf("chip=%s  flash=%uKB\n",
                ESP.getChipModel(), (unsigned)(ESP.getFlashChipSize() / 1024));

  for (int k = 0; k < N; k++) {
    int sda = LIST[k].sda, scl = LIST[k].scl;
    Serial.printf("try SDA=%d SCL=%d ... ", sda, scl);

    Wire.end();
    Wire.begin(sda, scl);
    Wire.setClock(100000);
    delay(30);

    /* 只看两个最常见的地址, 快 */
    int hit = -1;
    for (int a = 0; a < 2; a++) {
      int addr = (a == 0) ? 0x3C : 0x3D;
      Wire.beginTransmission(addr);
      if (Wire.endTransmission() == 0) { hit = addr; break; }
    }

    if (hit < 0) { Serial.println("no device"); continue; }
    Serial.printf("found 0x%02X, ", hit);

    if (d) { delete d; d = NULL; }
    d = new Adafruit_SSD1306(128, 64, &Wire, -1);
    bool ok = d->begin(SSD1306_SWITCHCAPVCC, hit);
    if (!ok) {
      Serial.print("begin(SWITCHCAPVCC) failed, ");
      ok = d->begin(SSD1306_EXTERNALVCC, hit);
      if (!ok) { Serial.println("EXTERNALVCC failed too"); delete d; d = NULL; continue; }
    }
    Serial.println("init OK -> drawing");

    pixelTest(sda, scl, hit);
    delay(1200);
    d->fillScreen(SSD1306_WHITE); d->display();   /* 满屏白闪一下 */
    delay(700);
    pixelTest(sda, scl, hit);

    Serial.println("### SCREEN IS ON ###");
    Serial.println("=================================");
    /* 停在这里, 不停重画, 免得被清屏 */
    while (true) { pixelTest(sda, scl, hit); delay(3000); }
  }

  Serial.println("=================================");
  Serial.println("### NO SCREEN FOUND ###");
  Serial.println("检查: VCC=3.3V / GND 共地 / SDA SCL 有没有插反 / 屏幕好坏");
  Serial.println("每 6 秒重试一次, 可以边接线边看 (板载灯会闪)");
}

void loop() {
  delay(6000);
  /* 闪灯表示还活着 */
  for (int i = 0; i < 2; i++) {
    digitalWrite(LED_PIN, LOW);  delay(80);
    digitalWrite(LED_PIN, HIGH); delay(80);
  }
  /* 再试一遍(可能她中途改了线) */
  for (int k = 0; k < N; k++) {
    int sda = LIST[k].sda, scl = LIST[k].scl;
    Wire.end();
    Wire.begin(sda, scl);
    Wire.setClock(100000);
    delay(20);
    for (int a = 0; a < 2; a++) {
      int addr = (a == 0) ? 0x3C : 0x3D;
      Wire.beginTransmission(addr);
      if (Wire.endTransmission() == 0) {
        Serial.printf("retry: SDA=%d SCL=%d -> 0x%02X\n", sda, scl, addr);
        if (d) { delete d; d = NULL; }
        d = new Adafruit_SSD1306(128, 64, &Wire, -1);
        if (d->begin(SSD1306_SWITCHCAPVCC, addr)) {
          pixelTest(sda, scl, addr);
          Serial.println("### SCREEN IS ON ###");
          while (true) { pixelTest(sda, scl, addr); delay(3000); }
        } else { delete d; d = NULL; }
      }
    }
  }
}
